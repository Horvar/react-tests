import SearchPage from './SearchPage';

export default SearchPage;
