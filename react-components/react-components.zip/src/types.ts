export type Person = {
  name: string;
  gender: string;
  height: string;
  mass: string;
};
